#pragma once
#include "majority_chain.hpp"

namespace percy
{

using mig = majority_chain;

}
