#pragma once

#include "encoders/ssv_encoder.hpp"
#include "encoders/ssv_fence_encoder.hpp"
#include "encoders/ssv_fence2_encoder.hpp"
#include "encoders/ssv_dag_encoder.hpp"
#include "encoders/msv_encoder.hpp"
#include "encoders/ditt_encoder.hpp"
#include "encoders/partial_dag_encoder.hpp"
#include "encoders/maj_encoder.hpp"
#include "encoders/mig_encoder.hpp"
#include "encoders/ditt_maj_encoder.hpp"
